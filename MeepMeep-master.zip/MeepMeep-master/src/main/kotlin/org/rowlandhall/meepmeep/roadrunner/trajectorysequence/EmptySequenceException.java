package org.rowlandhall.meepmeep.roadrunner.trajectorysequence;

/**
 * Exception thrown when a trajectory sequence is empty.
 */
public class EmptySequenceException extends RuntimeException {
    /* This does nothing right now. */
}